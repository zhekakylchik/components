<?
$MESS ['MAIN_FEEDBACK_COMPONENT_NAME'] = "Купить в 1 клик";
$MESS ['MAIN_FEEDBACK_COMPONENT_DESCR'] = "Форма для отправки сообщения с сайта на E-mail";
?>