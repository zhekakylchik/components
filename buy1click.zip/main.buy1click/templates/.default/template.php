<?
if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();
/**
 * Bitrix vars
 *
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponentTemplate $this
 * @global CMain $APPLICATION
 * @global CUser $USER
 */
?>
<div class="popup popup-buy1click df form" id="popup-buy1click">
	<div class="title">Купить в 1 клик!</div>
	<?if(!empty($arResult["ERROR_MESSAGE"]))
	{
		foreach($arResult["ERROR_MESSAGE"] as $v)
			ShowError($v);
		?>
		<script> var showPopup = '#popup-buy1click';</script>
		<?
	}
	if(strlen($arResult["OK_MESSAGE"]) > 0)
	{
		?>
    <script> var showPopup = '#popup-buy1click-after';</script>
		<script>
		/*$(function() {
			$('.popup-buy1click-after').show();
			$('.modalWindow').fadeIn(300);
			ShowPopupMsg();
		});*/
		</script>
		<?
	}
	?>
	<div class="attention">
		Заполните форму ниже и наши специалисты
свяжутся с Вами для уточнения деталей
и оформления заказа.
	</div>
	<form action="<?=POST_FORM_ACTION_URI?>" method="POST">
		<?=bitrix_sessid_post()?>
		<input type="hidden" name="PARAMS_HASH" value="<?=$arResult["PARAMS_HASH"]?>" />
		<input type="hidden" name="element_id" value="<?=$arResult["element_id"]?>" />
		<fieldset>
			<label for="user_name">
				Ваше имя
				<?if(empty($arParams["REQUIRED_FIELDS"]) || in_array("NAME", $arParams["REQUIRED_FIELDS"])):?>
					<span class="star">*</span>
				<?endif?>
			</label>
			<input type="text" name="user_name" value="<?=$arResult["AUTHOR_NAME"]?>" />
		</fieldset>
		<fieldset>
			<label for="user_phone">
				Номер телефона
				<?if(empty($arParams["REQUIRED_FIELDS"]) || in_array("PHONE", $arParams["REQUIRED_FIELDS"])):?>
					<span class="star">*</span>
				<?endif?>
			</label>
			<input type="text" name="user_phone" value="<?=$arResult["AUTHOR_PHONE"]?>" />
		</fieldset>
		
		<fieldset>
			<label for="MESSAGE">
				Комментарий к заказу:
				<?if(empty($arParams["REQUIRED_FIELDS"]) || in_array("MESSAGE", $arParams["REQUIRED_FIELDS"])):?>
					<span class="star">*</span>
				<?endif?>
			</label>
			<textarea name="MESSAGE"><?=$arResult["MESSAGE"]?></textarea>
		</fieldset>
		<fieldset>
  <input hidden="true" class="agree_checkbox" type="checkbox" id="confirm" name="confirm" checked="checked"/>
			<label class="agree_label" for="confirm">
Нажимая кнопку «Отправить», Вы соглашаетесь 
с <a href="/agreement/">политикой обработки персональных данных.</a>
</label>
      </fieldset>
		<?if($arParams["USE_CAPTCHA"] == "Y"):?>
			<input type="hidden" name="captcha_sid" value="<?=$arResult["capCode"]?>" />
			<fieldset>
				<label for="captcha_word">
					Введите сообщение на картинке
					<span class="star">*</span>
				</label>
				<img src="/bitrix/tools/captcha.php?captcha_sid=<?=$arResult["capCode"]?>" width="180" height="40" alt="CAPTCHA">
				<input type="text" name="captcha_word" size="30" maxlength="50" value="" />
			</fieldset>
		<?endif?>
		<div class="button">
			<input type="submit" name="submit" value="Отправить" />
		</div>
	</form>
</div>
