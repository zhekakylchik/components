<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Sale;
use Bitrix\Sale\DiscountCouponsManager;

/** @var CBitrixComponent $this */
/** @var array $arParams */
/** @var array $arResult */
/** @var string $componentPath */
/** @var string $componentName */
/** @var string $componentTemplate */
/** @global CDatabase $DB */
global $DB;
/** @global CUser $USER */
global $USER;
/** @global CMain $APPLICATION */
global $APPLICATION;

if (!CModule::IncludeModule("iblock") ||
    !CModule::IncludeModule("sale") ||
    !CModule::IncludeModule("catalog")) {
    die("Не установлены требуемые модули");
}

if (empty($_POST["store"])) {
    $_POST["store"] = @$_POST["store2"];
}
// Получаем список местоположений

$arOrder = array(
    "SORT" => "ASC",
    "CITY_NAME" => "ASC"
);
$arFilter = array(
    "!CITY_NAME" => false,
    "COUNTRY_LID" => "ru",
    "REGION_LID" => "ru",
    "CITY_LID" => "ru"
);
$res = CSaleLocation::GetList($arOrder, $arFilter);
$i = 0;
while ($arr = $res->GetNext()) {
    $arResult["LOCATIONS"][] = $arr;
}

// Получаем содержимое корзины

$arResult["TOTAL_PRICE"] = 0;
$resB = CSaleBasket::GetList(
    array("ID" => "ASC"),
    array("FUSER_ID" => CSaleBasket::GetBasketUserID(), "LID" => SITE_ID, "ORDER_ID" => "NULL"),
    false,
    false,
    array(
        "ID", "NAME", "CALLBACK_FUNC", "MODULE", "PRODUCT_ID", "QUANTITY", "DELAY", "CAN_BUY",
        "PRICE", "WEIGHT", "DETAIL_PAGE_URL", "NOTES", "CURRENCY", "VAT_RATE", "CATALOG_XML_ID",
        "PRODUCT_XML_ID", "SUBSCRIBE", "DISCOUNT_PRICE", "PRODUCT_PROVIDER_CLASS", "TYPE", "SET_PARENT_ID"
    )
);

$arResult["BASKET"] = array();

while ($arItem = $resB->GetNext()) {
    $arPrice = CPrice::GetByID($arr["PRODUCT_PRICE_ID"]);
    $arItem["QUANTITY"] = intval($arItem["QUANTITY"]);
    $arResult["TOTAL_PRICE"] += intval($arItem["PRICE"]) * $arItem["QUANTITY"];
    $arResult["BASKET"][] = $arItem;
}

$arTmpOrder = array(
    'SITE_ID' => SITE_ID,
    'USER_ID' => $GLOBALS["USER"]->GetID(),
    'ORDER_PRICE' => $arResult["TOTAL_PRICE"],
    'BASKET_ITEMS' => $arResult["BASKET"]
);

$arOptions = array(
    'COUNT_DISCOUNT_4_ALL_QUANTITY' => 'Y',
);

$arErrors = array();

CSaleDiscount::DoProcessOrder($arTmpOrder, $arOptions, $arErrors);
$arResult["TOTAL_PRICE"] = $arTmpOrder["ORDER_PRICE"];
$arResult["BASKET"] = $arTmpOrder["BASKET_ITEMS"];

foreach ($arResult["BASKET"] as $key => $arItem) {
    $arFilter = array("ID" => $arItem["PRODUCT_ID"]);
    $arSelect = array(
        "ID",
        "NAME",
        "DETAIL_PAGE_URL",
        "PROPERTY_MODEL",
        "SECTION_ID",
        "PROPERTY_MODEL",
        "PREVIEW_PICTURE"
    );
    $resE = CIBlockElement::GetList(array(), $arFilter, false, false, $arSelect);
    if ($arr = $resE->GetNext()) {
        $arResult["BASKET"][$key]["MODEL"] = $arr["PROPERTY_MODEL_VALUE"];
        $arResult["BASKET"][$key]["PREVIEW_PICTURE"] = CFile::GetFileArray($arr["PREVIEW_PICTURE"]);
        $ress = CIBlockSection::GetByID($arr["IBLOCK_SECTION_ID"]);
        if ($arrs = $ress->GetNext()) {
            $arResult["BASKET"][$key]["MODEL"] = $arrs["NAME"] . " " . $arResult["BASKET"][$key]["MODEL"];
        }
    }
}

$amounts = array();
$basket_ids = array();
foreach ($arResult["BASKET"] as $arItem) {
    $basket_ids[] = $arItem["PRODUCT_ID"];
}
$basket_ids = array_values(array_unique($basket_ids));
$arFilter = array("PRODUCT_ID" => $basket_ids, ">AMOUNT" => "0");
$res = CCatalogStoreProduct::GetList(array(), $arFilter);
while ($arr = $res->GetNext()) {
    $amounts[$arr["STORE_ID"]][] = $arr["PRODUCT_ID"];
}

// Получаем список складов

$arOrder = array(
    "XML_ID" => "DESC",
    "SORT" => "ASC",
    "TITLE" => "ASC"
);
$res = CCatalogStore::GetList($arOrder, array());
while ($arr = $res->GetNext()) {
    if (strlen($arr["ADDRESS"]) > 1) {
        $arr["SHOW_NAME"] = $arr["ADDRESS"];
    } else {
        $arr["SHOW_NAME"] = $arr["TITLE"];
    };
    $store_ids = array_values($amounts[$arr["ID"]]); // что есть на складе
    if ($arr["XML_ID"] == "main_warehouse") {
        $arResult["MAIN_WAREHOUSE_ID"] = $arr["ID"];
        $arResult["MAIN_WAREHOUSE_PRESENT"] =
            ($basket_ids == array_intersect($basket_ids, $store_ids)) || true;
    } else {
        if (($basket_ids == array_intersect($basket_ids, $store_ids)) || true) {
            $arResult["STORES"][] = $arr;
        }
    }
}

//

if ($_GET["ORDER_ID"]) {
    $arResult["ORDER_ID"] = intval($_GET["ORDER_ID"]);
}

// Список служб доставки
$res = CSaleDelivery::GetList(array("SORT" => "ASC"));
while ($arr = $res->GetNext()) {
    if ($arResult["MAIN_WAREHOUSE_PRESENT"] || $arr["ID"] != "1") {
        $arResult["DELIVERIES"][] = $arr;
    }
}
$arFilter = Array("IBLOCK_ID" => 20, "ACTIVE" => "Y");
$res = CIBlockElement::GetList(Array(), $arFilter);
while ($ob = $res->GetNextElement()) {
    $arFields = $ob->GetFields();
     $arResult["POINT"][] = $arFields;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST['confirm_policy'] != 'on')
        $arResult["ERRORS"][] = "Необходимо подтвердить согласие с пользовательским соглашением";
    if (empty($_POST["name"])) {
        $arResult["ERRORS"][] = "Пожалуйста, представьтесь";
    };
    if (empty($_POST["email"])) {
        $arResult["ERRORS"][] = "Укажите адрес электронной почты";
    };
    if (empty($_POST["phone"])) {
        $arResult["ERRORS"][] = "Укажите Ваш телефон";
    };
    if (empty($_POST["delivery"])) {
        $arResult["ERRORS"][] = "Укажите службу доставки";
    }
    if (empty($_POST["paymentType"])) {
        $arResult["ERRORS"][] = "Укажите способ оплаты";
    }
    /*if((empty($_POST["ex-works-city"]) && $_POST["delivery"]=="2") ||
     (empty($_POST["courier-city"]) && $_POST["delivery"]=="3")) {
        $arResult["ERRORS"][] = "Укажите город";
    };*/
    if (empty($_POST["store"]) && $_POST["delivery"] == "2") {
        $arResult["ERRORS"][] = "Укажите салон-партнёр";
    };
    if (empty($_POST["courier-address"]) && $_POST["delivery"] == "3") {
        $arResult["ERRORS"][] = "Укажите адрес доставки";
    }
    if (empty($arResult["ERRORS"])) {
   
        $arPerson = CSalePersonType::GetByID(1);
        if ($arPerson) {
            $res = CSalePaySystem::GetList();
            if ($arPaySystem = $res->GetNext()) {

                $basket_user_id = \CSaleBasket::GetBasketUserID();
                 $basket = Sale\Basket::loadItemsForFUser($basket_user_id, SITE_ID);

                $order = Bitrix\Sale\Order::create(SITE_ID, ($basket_user_id == 1) ? $basket_user_id : 2);
                $order->setPersonTypeId($arPerson["ID"]);
                $order->setBasket($basket);

                $shipmentCollection = $order->getShipmentCollection();
                $shipment = $shipmentCollection->createItem(Bitrix\Sale\Delivery\Services\Manager::getObjectById($_POST["delivery"]));
                $shipment->setField("DELIVERY_NAME", $shipment->getDelivery()->getName());

                $shipmentItemCollection = $shipment->getShipmentItemCollection();

                foreach ($basket as $basketItem) {
                    $item = $shipmentItemCollection->createItem($basketItem);
                    $item->setQuantity($basketItem->getQuantity());
                }

                $paymentCollection = $order->getPaymentCollection();

                $payment = $paymentCollection->createItem(Bitrix\Sale\PaySystem\Manager::getObjectById($arPaySystem["ID"]));

                $payment->setField("SUM", $order->getPrice());
                $payment->setField("CURRENCY", $order->getCurrency());
                 $result = $order->save();
                if (!$result->isSuccess()) {
                    $arResult["ERRORS"][] = $result->getErrors();
                } else {

                    /*
                                $arFields = array(
                                    "LID" => SITE_ID,
                                    "PERSON_TYPE_ID" => $arPerson["ID"],
                                    "PAYED" => "N",
                                    "CANCELED" => "N",
                                    "STATUS_ID" => "N",
                                    "PRICE" => $_POST["newprice"],
                                    "CURRENCY" => "RUB",
                                    "USER_ID" => ($USER->GetID() ? IntVal($USER->GetID()) : 2),
                                    "PAY_SYSTEM_ID" => $arPaySystem["ID"],
                                    "DISCOUNT_VALUE" => 0.0,
                                    "DELIVERY_ID" => $_POST["delivery"]
                                );
                                $ORDER_ID = CSaleOrder::Add($arFields);
                                $ORDER_ID = IntVal($ORDER_ID);
                                if($ORDER_ID <= 0) {
                                    if($ex = $APPLICATION->GetException()) {
                                        $arResult["ERRORS"][] = $ex->GetString();
                                    };
                                } else {
                                    CSaleBasket::OrderBasket($ORDER_ID);
                                    CSaleOrder::Update($ORDER_ID, array("PRICE" => $_POST["newprice"]));*/
                    // Добавляем свойства
                    $ORDER_ID = $result->getId();


                    $coupon = array_keys(DiscountCouponsManager::get(true, array(), true, true));
                    $coupon = implode(',', $coupon);

                    $arFields = array(
                        "ORDER_ID" => $ORDER_ID,
                        "NAME" => "ФИО",
                        "ORDER_PROPS_ID" => 1,
                        "VALUE" => $_POST["name"]
                    );
                    CSaleOrderPropsValue::Add($arFields);

                    if ($_POST["delivery"] == "1") {
                        $arFields = array(
                            "ORDER_ID" => $ORDER_ID,
                            "NAME" => "Склад",
                            "ORDER_PROPS_ID" => 3,
                            "VALUE" => $arResult["MAIN_WAREHOUSE_ID"]
                        );
                        CSaleOrderPropsValue::Add($arFields);
                    } elseif ($_POST["delivery"] == "2") {
                        /*$arFields = array(
                            "ORDER_ID" => $ORDER_ID,
                            "NAME" => "Местоположение",
                            "ORDER_PROPS_ID" => 2,
                            "VALUE" => $_POST["ex-works-city"]
                        );
                        CSaleOrderPropsValue::Add($arFields);*/
                        $arFields = array(
                            "ORDER_ID" => $ORDER_ID,
                            "NAME" => "Склад",
                            "ORDER_PROPS_ID" => 3,
                            "VALUE" => $_POST["store"]
                        );
                        CSaleOrderPropsValue::Add($arFields);
                    } elseif ($_POST["delivery"] == "3") {
                        $arFields = array(
                            "ORDER_ID" => $ORDER_ID,
                            "NAME" => "Город доставки",
                            "ORDER_PROPS_ID" => 6,
                            "VALUE" => $_POST["courier-city"]
                        );
                        CSaleOrderPropsValue::Add($arFields);
                        $arFields = array(
                            "ORDER_ID" => $ORDER_ID,
                            "NAME" => "Адрес доставки",
                            "ORDER_PROPS_ID" => 7,
                            "VALUE" => $_POST["courier-address"]
                        );
                        CSaleOrderPropsValue::Add($arFields);
                   } elseif($_POST["delivery"]=="5") {
							$arFields = array(
								"ORDER_ID" => $ORDER_ID,
								"NAME" => "самовывоз из пункта выдачи",
								"ORDER_PROPS_ID" => 11,
								"VALUE" => $_POST["chosenPost"]
							);
CSaleOrderPropsValue::Add($arFields);
$arFields = array(
								"ORDER_ID" => $ORDER_ID,
								"NAME" => "самовывоз из пункта выдачи",
								"ORDER_PROPS_ID" => 12,
								"VALUE" => $_POST["addresPost"]
							);

							CSaleOrderPropsValue::Add($arFields);
						};

                    $arFields = array(
                        "ORDER_ID" => $ORDER_ID,
                        "NAME" => "E-Mail",
                        "ORDER_PROPS_ID" => 4,
                        "VALUE" => $_POST["email"]
                    );
                    CSaleOrderPropsValue::Add($arFields);

                    $arFields = array(
                        "ORDER_ID" => $ORDER_ID,
                        "NAME" => "Телефон",
                        "ORDER_PROPS_ID" => 5,
                        "VALUE" => $_POST["phone"]
                    );
                    CSaleOrderPropsValue::Add($arFields);

                    $arFields = array(
                        "ORDER_ID" => $ORDER_ID,
                        "NAME" => "Комментарий к заказу",
                        "ORDER_PROPS_ID" => 8,
                        "VALUE" => $_POST["comment"]
                    );
                    CSaleOrderPropsValue::Add($arFields);

                    // Отсылаем e-mail

                    $strOrderList = "";
                    $arBasketList = array();
                    $dbBasketItems = CSaleBasket::GetList(
                        array("NAME" => "ASC"),
                        array("ORDER_ID" => $ORDER_ID),
                        false,
                        false,
                        array("ID", "PRODUCT_ID", "NAME", "QUANTITY",
                            "PRICE", "CURRENCY", "TYPE", "SET_PARENT_ID")
                    );
                    while ($arItem = $dbBasketItems->Fetch()) {
                        if (CSaleBasketHelper::isSetItem($arItem)) {
                            continue;
                        }
                        $arBasketList[] = $arItem;
                    }

                    $arBasketList = getMeasures($arBasketList);

   
                    foreach ($arBasketList as $arItem) {
                        $rsPItem = CIBlockElement::GetByID($arItem["PRODUCT_ID"]);
                        $arPItem = $rsPItem->GetNext();
                        $arPItem["PREVIEW_PICTURE"] = CFile::GetFileArray($arPItem["PREVIEW_PICTURE"]);
                        $model = CIBlockSection::GetByID($arPItem["IBLOCK_SECTION_ID"]);
                        $model = $model->Fetch();
                        $model = $model["NAME"];

                        $measureText = (isset($arItem["MEASURE_TEXT"]) && strlen($arItem["MEASURE_TEXT"])) ? $arItem["MEASURE_TEXT"] : "шт.";
                        $strOrderList .= '<div style = "display:inline-block; vertical-align:top; padding:0 10px; box-sizing:border-box; width:32%; text-align:center; margin-top:5px; margin-bottom:20px">';
                        $strOrderList .= '<a href="' . $arPItem["DETAIL_PAGE_URL"] . '"><img style="max-width:160px" src="' . $arPItem["PREVIEW_PICTURE"]["SRC"] . '"/></a>';
                        $strOrderList .= "<p><b>Часы " . $model . "</b><br> " . $arItem["NAME"] . " <br> " . $arItem["QUANTITY"] . " " . $measureText . " <br>" . SaleFormatCurrency($arItem["PRICE"], $arItem["CURRENCY"]) . "</p>";
                        $strOrderList .= "</div>";
                    }

                    $arEventFields = array(
                        "ORDER_ID" => $ORDER_ID,
                        "ORDER_DATE" => date("m.d.y"),
                        "NAME" => $_POST["name"],
                        "USER_EMAIL" => $_POST["email"],
                        "PHONE" => $_POST["phone"],
                        "PROMO" => $coupon,
                        "CART" => $_POST["cart"],
                        "PRICE" => $_POST["newprice"],
                        "SALE_EMAIL" => COption::GetOptionString("sale", "order_email", COption::GetOptionString("main", "email_from")),
                        "EMAIL" => COption::GetOptionString("sale", "order_email", COption::GetOptionString("main", "email_from")),
                        "ORDER_LIST" => $strOrderList,
                        "COMMENT" => $_POST['comment'],
                    );
                    if ($_POST["delivery"] == "1") {
                        $arEventFields["DELIVERY"] = "самовывоз со склада";
                    } elseif ($_POST["delivery"] == "2") {
                        $arEventFields["DELIVERY"] = "самовывоз из салона-партнёра\n";
                        $arEventFields["DELIVERY"] .= "Салон: " . $_POST["store"];
                    } elseif ($_POST["delivery"] == "3") {
                        $arEventFields["DELIVERY"] = "курьерская доставка\n";
                        $arEventFields["DELIVERY"] .= "Город: " . $_POST["courier-city"] . "\n";
                        $arEventFields["DELIVERY"] .= "Адрес: " . $_POST["courier-address"];
                    } elseif ($_POST["delivery"] == "5") {
                        $arEventFields["DELIVERY"] = "самовывоз из пункта выдачи курьерской службы\n";
                        $arEventFields["DELIVERY"] .= "Пункт выдачи: " . $_POST["chosenPost"] . "\n";
$arEventFields["DELIVERY"].= "Адрес пункта: ".$_POST["addresPost"]."\n";
                    };

                    if ($_POST["paymentType"] == "ROBOKASSA") {
                        $arEventFields["OPLATA"] = "Онлайн оплата банковской картой";
                    } elseif ($_POST["paymentType"] == "NAL") {
                        $arEventFields["OPLATA"] = "При получении наличными";
                    } elseif ($_POST["paymentType"] == "CART") {
                        $arEventFields["OPLATA"] = "При получении банковской картой";
                    } elseif ($_POST["paymentType"] == "AC") {
                        $arEventFields["OPLATA"] = "С банковской карты";
                    } elseif ($_POST["paymentType"] == "GP") {
                        $arEventFields["OPLATA"] = "По коду через терминал";
                    } elseif ($_POST["paymentType"] == "WM") {
                        $arEventFields["OPLATA"] = "Сo счета WebMoney";
                    } else {
                        $arEventFields["OPLATA"] = "Со счета в Яндекс.Деньгах";
                    }

                    if ($_POST["subscribe_email"] == 'on')
                        $arEventFields["SUBSCRIBE_EMAIL"] = "<p>Оформлена подписка на новости и специальные предложения по электронной почте</p>";

                    if ($_POST["subscribe_sms"] == 'on')
                        $arEventFields["SUBSCRIBE_SMS"] = "<p>Оформлена подписка на новости и специальные предложения по sms</p>";

                    CEvent::Send("SALE_NEW_ORDER", SITE_ID, $arEventFields);
                    if ($_POST["paymentType"] != "NAL" and $_POST["paymentType"] != "CART" and $_POST["paymentType"] != "ROBOKASSA") {
                        if ($_POST["paymentType"] == "YA") {
                            $_POST["paymentType"] = "";
                        }
                        ?>
                        <div style="display:none">
                            <form name=ShopForm method="POST" action="https://money.yandex.ru/eshop.xml">
                                <font face=tahoma size=2>

                                    <input type="hidden" name="scid" value="11581">
                                    <input type="hidden" name="ShopID" value="19426">
                                    <input type="hidden" name="shopSuccessURL"
                                           value="http://<?= SITE_SERVER_NAME ?>/buy/order.php?ORDER_ID=<?= $ORDER_ID ?>">

                                    Идентификатор клиента/Номер заказа:<br>
                                    <input type=text name="CustomerNumber" size="43" value="<?= $ORDER_ID ?>"><br><br>
                                    Сумма:<br>
                                    <input type=text name="Sum" size="43" value="<?= $_POST["newprice"] ?>"><br><br>  
                                    Ф.И.О.:<br>
                                    <input type=text name="CustName" size="43" value="<?= $_POST["name"] ?>"><br><br>
                                    Адрес доставки:<br>
                                    <input type=text name="CustAddr" size="43"
                                           value="<?= $arEventFields["DELIVERY"] ?>"> <br><br>
                                    E-mail:<br>
                                    <input type=text name="CustEMail" size="43" value="<?= $_POST["email"] ?>"><br><br> 
                                    Содержание заказа:<br>
                                    <textarea rows="10" name="OrderDetails" cols="34">
									<?= $strOrderList ?>
								</textarea><br><br>
                                    Способ оплаты:<br><br>
                                    <input name="paymentType" checked="checked" value="<?= $_POST["paymentType"] ?>"
                                           type="radio">
                                    <input id="but" type=submit value="Оплатить"><br>
                            </form>
                            <script>
                                document.ShopForm.submit();
                            </script>
                        </div>

                        <?
                    } else {
                        LocalRedirect($APPLICATION->GetCurPage() . "?ORDER_ID=" . $ORDER_ID . "&paymentType=" . $_POST["paymentType"]);

                    }
                }
            } else {
                $arResult["ERRORS"][] = "Не задано ни одной платёжной системы";
            }
        } else {
            $arResult["ERRORS"][] = "Не задано ни одного типа плательщика";
        }
        
    }
}


$this->IncludeComponentTemplate();
?>