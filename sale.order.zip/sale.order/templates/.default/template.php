<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<h1>Оформление заказа</h1>
<?if($arResult["ORDER_ID"]):?>
	<?/*if ($_REQUEST["paymentType"]!="CART" and $_REQUEST["paymentType"]!="NAL"):?>
		<form name=ShopForm method="POST" action="https://money.yandex.ru/eshop.xml">
			<font face=tahoma size=2>
			
			<input type="hidden" name="scid" value="11581">
			<input type="hidden" name="ShopID" value="19426"> 
			
			Идентификатор клиента/Номер заказа:<br> 
			<input type=text name="CustomerNumber" size="43" value="<?=$_REQUEST["ORDER_ID"]?>"><br><br> 
			Сумма:<br> 
			<input type=text name="Sum" size="43"  value="<?=$_REQUEST["PRICE"]?>"><br><br>   
			Ф.И.О.:<br> 
			<input type=text name="CustName" size="43" value="<?=$_REQUEST["NAME"]?>"><br><br>
			Адрес доставки:<br> 
			<input type=text name="CustAddr" size="43" value="<?=$_REQUEST["DELIVERY"]?>"> <br><br> 
			E-mail:<br> 
			<input type=text name="CustEMail" size="43" value="<?=$_REQUEST["EMAIL"]?>"><br><br>  
			Содержание заказа:<br> 
			<textarea rows="10" name="OrderDetails" cols="34">
				<?=$_REQUEST["ORDER_LIST"]?>
			</textarea><br><br> 
			Способ оплаты:<br><br>
			<input name="paymentType" checked="checked" value="<?=$_REQUEST["paymentType"]?>" type="radio">
			<input id="but" type=submit value="Оплатить"><br> 
		</form>	
		<script>
			document.ShopForm.submit();
		</script>
	<?else:*/?>
	Спасибо за ваш заказ! 
	Ваш заказ поступил в обработку. 
	Номер Вашего заказа: <?=$arResult["ORDER_ID"]?>
<?else:?>
	<?if($arResult["ERRORS"]):?>
		<p style="color: red"><?=implode('<br/>', $arResult["ERRORS"]);?></p>
	<?endif?>
	<form action="<?=$APPLICATION->GetCurPage()?>" method="POST">
		<p>
			<label for="name">Фамилия, имя, отчество</label><br/>
			<input name="name" size="50" value="<?=htmlspecialchars($_REQUEST["name"])?>" />
		</p>
		<p>
			<label for="email">Адрес электронной почты</label><br/>
			<input name="email" size="50" value="<?=htmlspecialchars($_REQUEST["email"])?>" />
		</p>
		<p>
			<label for="phone">Телефон</label><br/>
			<input name="phone" size="50" value="<?=htmlspecialchars($_REQUEST["phone"])?>" />
		</p>
		<p>
			<label for="promo">Промокод на скидку</label><br/>
			<input name="promo" size="50" value="<?=htmlspecialchars($_REQUEST["promo"])?>" />
		</p>
		<p>
			<label for="cart">Номер дисконтной карты</label><br/>
			<input name="cart" size="50" value="<?=htmlspecialchars($_REQUEST["cart"])?>" />
		</p>
		<p><strong>Способ получения</strong></p>
		<p id="deliveries">
			<?foreach($arResult["DELIVERIES"] as $arDelivery):?>
				
				<input type="radio" name="delivery" value="<?=$arDelivery["ID"]?>" id="d<?=$arDelivery["ID"]?>" <?if($_REQUEST["delivery"]==$arDelivery["ID"]):?>checked<?endif?> />
				<label for="d<?=$arDelivery["ID"]?>"><?=$arDelivery["NAME"]?></label>
				<br/>
			<?endforeach?>
		</p>
		<p class="delivery-dep d3">
			<label>Город:</label><br/>
			<input class="delivery-dep d3" name="courier-city" size="50" value="<?=htmlspecialchars($_REQUEST["courier-city"])?>" />
		</p>
		<div class="delivery-dep d2">
			<fieldset class="store">
				<label for="store">Пункт выдачи</label><br/>
				<select name="store" size="5">
					<?foreach($arResult["STORES"] as $arStore):?>
						<option value='<?=$arStore['TITLE']?>' <?if($_REQUEST['store']==$arStore['TITLE']):?>selected<?endif?>>
							<?=$arStore['SHOW_NAME']?>
						</option>
					<?endforeach?>
				</select>
			</fieldset>
			<p class="no-store" style="display: none;">
				К сожалению, в выбранном городе нет салонов, в которых есть в наличии выбранные Вами часы.
			</p>
		</div>
		<div class="delivery-dep d5">
			<fieldset class="store">
				<label for="store">Пункт выдачи</label><br/>
				<select name="store" size="5">
					<?foreach($arResult["POINT"] as $arStore):?>
						<option value='<?=$arStore['NAME']?>' <?if($_REQUEST['store']==$arStore['NAME']):?>selected<?endif?>>
							<?=$arStore['NAME']?>
						</option>
					<?endforeach?>
				</select>
			</fieldset>
			<br />
			<a href="/work/delivery/" target="_blank">Адреса и схемы проезда пунктов самовывоза </a>
			<p class="no-store" style="display: none;">
				К сожалению, в выбранном городе нет салонов, в которых есть в наличии выбранные Вами часы.
			</p>
		</div>
		<p class="delivery-dep d3">
			<label for="courier-address">Адрес доставки</label><br/>
			<textarea cols="49" rows="3" name="courier-address"><?=htmlspecialchars($_REQUEST["courier-address"])?></textarea>
		</p>	<br />
		<p><strong>Способ оплаты:</strong></p>
			<input name="paymentType" sale = "0" id="NAL" value="NAL" type="radio"><label for="NAL">При получении наличными</label><br>
			<input name="paymentType" sale = "0" id="CART" value="CART" type="radio"><label for="CART">При получении банковской картой</label><br>
			<input name="paymentType" sale = "3" id="YA" value="YA" type="radio"><label for="YA">Со счета в Яндекс.Деньгах</label><br>
			<input name="paymentType" sale = "3" id="AC" value="AC" type="radio"><label for="AC">С банковской карты</label><br>
			<input name="paymentType" sale = "3" id="GP" value="GP" type="radio"><label for="GP">По коду через терминал</label><br>
			<input name="paymentType" sale = "3" id="WM" value="WM" type="radio"><label for="WM">Сo счета WebMoney</label><br><br>	
		<p>
			<input name="price" type="hidden" value="<?=$arResult["TOTAL_PRICE"]?>" >
			<input name="newprice" type="hidden" value="<?=$arResult["TOTAL_PRICE"]?>" >
<?if (count($arResult['BASKET']) > 0) {?>
	<script type="text/javascript">
		var yaParams = {
			order_id: '<?=$arResult['ORDER_ID']?>',
			order_price: '<?=$arResult['TOTAL_PRICE']?>', 
			currency: "RUR",
			exchange_rate: 1,
			goods: [
				<?foreach ($arResult['BASKET'] as $basket_item) {?>
				{
					id: '<?=$basket_item['PRODUCT_ID']?>', 
					name: '<?=$basket_item['NAME']?>', 
					price: '<?=$basket_item['PRICE']?>',
					quantity: '<?=$basket_item['QUANTITY']?>'
				},
					<?}?>
			]
		};
	</script>
<?}?>
			<input type="submit" value="Заказать" onclick="yaCounter24415375.reachGoal('ORDER'); return true;" />
			<div class="bx_ordercart">
				<div id="basket_items_list">
					<div class="bx_ordercart_order_table_container">
						<table>
							<thead>
								<tr>
									<td class="margin"></td>
									<td class="item" colspan="2">
										Товары							
									</td>
									<td class="custom">
										Количество							
									</td>
									<td class="price">
										Цена							
									</td>
								</tr>
							</thead>
							<tbody>
								<?foreach($arResult["BASKET"] as $arItem):?>			
									<tr>
										<td class="margin"></td>
										<td class="itemphoto">
											<div class="bx_ordercart_photo_container">
												<a href="<?=$arItem["DETAIL_PAGE_URL"]?>">		
													<div class="bx_ordercart_photo" style="background-image:url('<?=$arItem["PREVIEW_PICTURE"]["SRC"]?>')"></div>
												</a>									
											</div>
										</td>
										<td class="item">
											<h2 class="bx_ordercart_itemtitle">
												<?=$arItem["NAME"]?>
											</h2>
											<div class="bx_ordercart_itemart"></div>
										</td>
										<td class="custom">
											<div class="centered">
												<table cellspacing="0" cellpadding="0" class="counter">
													<tbody>
														<tr>
															<td><?=$arItem["QUANTITY"]?></td>
															<td> шт</td>
														</tr>
													</tbody>
												</table>
											</div>
										</td>
										<td class="price">
											<div class="current_price"><?=number_format($arItem["PRICE"], 0, ',', ' ')?> руб.</div>
											<div class="old_price"><?=number_format($arItem["PRICE"]+$arItem["DISCOUNT_PRICE"], 0, ',', ' ')?> руб.</div>
											<div class="type_price">Тип цены</div>
											<div class="type_price_value">Цена магазина SWT</div>
										</td>
										<td class="margin"></td>
									</tr>
								<?endforeach?>				
							</tbody>
						</table>
					</div>
					<div class="bx_ordercart_order_pay">		
						<div class="bx_ordercart_order_pay_right">
							<table class="bx_ordercart_order_sum">
								<tbody>
									<tr>
										<td class="fwb">Итого:</td>
										<td class="fwb"><?=number_format($arResult["TOTAL_PRICE"], 0, ',', ' ')?> руб.</td>
									</tr>
									<tr class="price_sale" style="display:none">
										<td class="custom_t1">Сумма к оплате (с учетом скидки 3%) за онлайн платеж</td>
										<td class="custom_t2" id="price"></td>
									</tr>
								</tbody>
							</table>
							<div style="clear:both;"></div>
						</div>
						<div style="clear:both;"></div>
					</div>
				</div>
			</div>
	
			<input type="submit" value="Заказать" onclick="yaCounter24415375.reachGoal('ORDER'); return true;" />
		</p>
	</form>

	<script>
		function deliveryProperties(){
			$('.delivery-dep').hide();
			var id = $('#deliveries input:checked').val();
			$('.delivery-dep.d' + id).show();
		}
	
		$(function(){
			$('input[name=delivery]').change(deliveryProperties);
			deliveryProperties();
		});
		
		$( 'input[name=paymentType]' ).on( 'click', function() {
		var sale = $('input[name=paymentType]:checked').attr("sale");
		if(sale > 0){
			$('.price_sale').show();
		}
		else{
			$('.price_sale').hide();
		}
		
		var price = $('input[name=price]').val();
		var newprice = Math.ceil(price-(price/100)*sale);
		$('input[name=newprice]').val(newprice);
		$('#price').html(format_number(newprice) + ' руб.');
		console.log(format_number(newprice));
		});
		
		function format_number (number, places, symbol, thousand, decimal) { 
			places = !isNaN(places = Math.abs(places)) ? places : 0;
			symbol = symbol !== undefined ? symbol : "";
			thousand = thousand || " ";
			decimal = decimal || ".";
			var negative = number < 0 ? "-" : "",
				i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
				j = (j = i.length) > 3 ? j % 3 : 0;
			
			return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");	
		}	
	</script>
<?endif?>




