<?
$MESS ['T_IBLOCK_DESC_LIST'] = "Продукция на складе";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "Список продукции для конкретного склада";
$MESS ['T_IBLOCK_DESC_STORE'] = "Склад";
?>